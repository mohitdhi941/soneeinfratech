import Link from "next/link";
import Hero from "@/components/Hero";
import SectionHeading from "@/components/SectionHeading";
import ServiceCard from "@/components/ServiceCard";
import ProjectCard from "@/components/ProjectCard";
import StatsSection from "@/components/StatsSection";
import CTASection from "@/components/CTASection";
import Marquee from "@/components/Marquee";
import BentoWhy from "@/components/BentoWhy";
import Testimonials from "@/components/Testimonials";
import PestBand from "@/components/PestBand";
import Faq from "@/components/Faq";
import Reveal from "@/components/Reveal";
import Icon from "@/components/Icon";
import { services, journey } from "@/data/services";
import projects from "@/data/projects";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "Construction Company: Residential, Commercial & Township Projects",
  description: "End-to-end construction from foundation to final handover: residential, commercial and township projects, with landscaping, plantation and pest control (termites, bed bugs, cockroaches).",
  path: "/",
});

export default function Home() {
  return (
    <>
      <Hero />
      <Marquee />
      <section id="intro" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-20">
        <Reveal>
          <SectionHeading eyebrow="WHAT WE DO" title="Everything your project needs, under one roof" text="Foundation, structure, services, interiors, exteriors and landscaping are all handled by one accountable team." />
        </Reveal>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {["end-to-end-construction", "residential-construction", "commercial-construction", "township-development", "landscaping-gardening", "pest-control-services"].map((slug) => services.find((x) => x.slug === slug)).map((s) => (<ServiceCard key={s.slug} service={s} />))}
        </div>
        <Link href="/what-we-do" className="mt-8 inline-flex min-h-12 items-center gap-2 font-medium text-brass-600">See all {services.length} services <Icon name="arrow" className="h-4 w-4" /></Link>
      </section>

      <BentoWhy />
      <PestBand />
      <section className="bg-stone-100 py-20">
        <div className="mx-auto max-w-6xl px-5">
          <Reveal><SectionHeading eyebrow="OUR PROCESS" title="From first excavation to final keys" text={`${journey.length} stages, one team, no hand-offs between contractors.`} /></Reveal>
          <ol className="mt-10 flex snap-x gap-3 overflow-x-auto pb-4 lg:grid lg:grid-cols-5 lg:overflow-visible" aria-label="Construction journey">
            {journey.map((j, i) => (
              <li key={j.title} className="min-w-[70%] snap-start rounded-3xl border border-stone-200 bg-white p-5 sm:min-w-[40%] lg:min-w-0">
                <span className="font-display text-3xl text-brass">{i + 1}</span>
                <h3 className="mt-2 text-lg">{j.title}</h3>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <StatsSection />

      <section className="mx-auto max-w-6xl px-5 py-20">
        <Reveal><SectionHeading eyebrow="PORTFOLIO" title="Selected projects" text="A look at the kind of work we deliver. Sample content shown." /></Reveal>
        <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {projects.slice(0, 3).map((p) => (<li key={p.slug}><ProjectCard project={p} /></li>))}
        </ul>
        <Link href="/projects" className="mt-8 inline-flex min-h-12 items-center gap-2 font-medium text-brass-600">View all projects <Icon name="arrow" className="h-4 w-4" /></Link>
      </section>
      <Testimonials />
      <Faq />
      <CTASection />
    </>
  );
}
