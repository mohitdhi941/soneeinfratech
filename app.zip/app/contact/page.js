import PageHeader from "@/components/PageHeader";
import EnquiryForm from "@/components/EnquiryForm";
import Icon from "@/components/Icon";
import JsonLd from "@/components/JsonLd";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/lib/site";

export const metadata = buildMetadata({
  title: "Contact Us: Get a Construction Quote",
  description: "Contact our construction team. Share your project details and get a quote for residential, commercial or township construction.",
  path: "/contact",
});

export default function ContactPage() {
  const cards = [
    { icon: "pin", title: "Address", lines: [site.address] },
    { icon: "phone", title: "Phone", lines: [site.phone], href: `tel:${site.phone.replace(/\s/g, "")}` },
    { icon: "mail", title: "Email", lines: [site.email], href: `mailto:${site.email}` },
    { icon: "clock", title: "Working hours", lines: site.hours },
  ];
  const schema = { "@context": "https://schema.org", "@type": "ContactPage", name: `Contact ${site.name}`, url: `${site.url}/contact` };
  return (
    <>
      <JsonLd data={schema} />
      <PageHeader title="Contact us" text="Tell us about your project and we will get back to you." image="/images/commercial.svg" />
      <section className="mx-auto max-w-6xl px-5 py-16">
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <li key={c.title} className="rounded-3xl border border-stone-200 bg-white p-6">
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-brass-100 text-brass-600"><Icon name={c.icon} /></span>
              <h2 className="mt-4 text-xl">{c.title}</h2>
              {c.lines.map((l) => c.href ? <a key={l} href={c.href} className="mt-1 block text-ink-500 hover:text-brass-600">{l}</a> : <p key={l} className="mt-1 text-ink-500">{l}</p>)}
            </li>
          ))}
        </ul>
      </section>
      <section id="enquiry" className="scroll-mt-24 bg-stone-100 py-16">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <h2 className="text-3xl sm:text-4xl">Start your project</h2>
            <p className="mt-4 text-ink-500">Share a few details and our team will reply with next steps. Fields marked * are required.</p>
          </div>
          <div className="lg:col-span-3"><EnquiryForm /></div>
        </div>
      </section>
      <section aria-labelledby="map-title" className="mx-auto max-w-6xl px-5 py-16">
        <h2 id="map-title" className="text-3xl">Find us</h2>
        {/* Replace this placeholder with a Google Maps <iframe> embed (loading="lazy") */}
        <div className="mt-6 flex aspect-[16/10] items-center justify-center rounded-3xl border border-dashed border-stone-300 bg-stone-100 text-ink-500 sm:aspect-[16/6]">Google Maps embed placeholder</div>
      </section>
    </>
  );
}
