import PageHeader from "@/components/PageHeader";
import SectionHeading from "@/components/SectionHeading";
import ServiceCard from "@/components/ServiceCard";
import Journey from "@/components/Journey";
import CTASection from "@/components/CTASection";
import JsonLd from "@/components/JsonLd";
import { services } from "@/data/services";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "What We Do: Construction, Finishing & Landscaping Services",
  description: "End-to-end construction, residential, commercial and township development, interior and exterior finishing, landscaping, gardening, plantation and pest control.",
  path: "/what-we-do",
  keywords: ["construction services", "turnkey construction", "landscaping services", "township development", "pest control services"],
});

export default function WhatWeDoPage() {
  const schema = { "@context": "https://schema.org", "@type": "ItemList", itemListElement: services.map((s, i) => ({ "@type": "ListItem", position: i + 1, item: { "@type": "Service", name: s.title, description: s.description } })) };
  return (
    <>
      <JsonLd data={schema} />
      <PageHeader title="What we do" text="Complete construction services, from the first foundation to landscaping and final handover." image="/images/township.svg" />
      <section className="mx-auto max-w-6xl px-5 py-20">
        <SectionHeading title="Our services" text="Choose a single service or let us manage the whole project." />
        <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (<li key={s.slug} id={s.slug}><ServiceCard service={s} detailed /></li>))}
        </ul>
      </section>
      <section className="bg-stone-100 py-20">
        <div className="mx-auto max-w-6xl px-5">
          <SectionHeading title="Our construction journey" text="Foundation, structure, exterior, interior, finishing and handover, all managed in one flow." />
          <Journey />
        </div>
      </section>
      <CTASection />
    </>
  );
}
