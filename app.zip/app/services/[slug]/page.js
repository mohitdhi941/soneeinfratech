import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHeader from "@/components/PageHeader";
import ServiceCard from "@/components/ServiceCard";
import CTASection from "@/components/CTASection";
import Icon from "@/components/Icon";
import JsonLd from "@/components/JsonLd";
import { services, getService } from "@/data/services";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/lib/site";

export function generateStaticParams() {
  return services.map((s) => ({ slug: s.slug }));
}

export function generateMetadata({ params }) {
  const s = getService(params.slug);
  if (!s) return {};
  return buildMetadata({ title: `${s.title} | ${site.name}`, description: s.description, path: `/services/${s.slug}`, keywords: s.keywords, image: s.image });
}

export default function ServicePage({ params }) {
  const s = getService(params.slug);
  if (!s) notFound();
  const others = services.filter((x) => x.slug !== s.slug).slice(0, 3);
  const schema = { "@context": "https://schema.org", "@type": "Service", name: s.title, description: s.long, serviceType: s.title, provider: { "@type": "Organization", name: site.name, url: site.url }, areaServed: site.serviceAreas, image: `${site.url}${s.image}` };
  return (
    <>
      <JsonLd data={schema} />
      <PageHeader title={s.title} text={s.description} image={s.image} alt={`${s.title} by ${site.name}`} crumbs={[{ name: "What We Do", href: "/what-we-do" }, { name: s.title, href: `/services/${s.slug}` }]} />
      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-16 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <h2 className="text-3xl sm:text-4xl">About this service</h2>
          <p className="mt-4 text-lg leading-relaxed text-ink-500">{s.long}</p>
          <h2 className="mt-10 text-3xl">What is included</h2>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {s.points.map((p) => (<li key={p} className="flex items-start gap-3 rounded-2xl border border-stone-200 bg-white p-4"><Icon name="check" className="mt-0.5 h-5 w-5 shrink-0 text-brass" />{p}</li>))}
          </ul>
        </div>
        <div className="relative aspect-[4/5] overflow-hidden rounded-3xl lg:col-span-2">
          <Image src={s.image} alt={`${s.title} illustration`} fill sizes="(min-width:1024px) 40vw, 100vw" className="object-cover" />
        </div>
      </section>
      <section className="bg-stone-100 py-16">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="text-3xl sm:text-4xl">Related services</h2>
          <ul className="mt-8 grid gap-6 md:grid-cols-3">{others.map((o) => (<li key={o.slug}><ServiceCard service={o} /></li>))}</ul>
          <Link href="/what-we-do" className="mt-8 inline-flex min-h-12 items-center gap-2 font-medium text-brass-600">All services <Icon name="arrow" className="h-4 w-4" /></Link>
        </div>
      </section>
      <CTASection title={`Need ${s.title.toLowerCase()}?`} text="Tell us about your site and we will get back to you." />
    </>
  );
}
