import { site } from "@/lib/site";

export default function manifest() {
  return {
    name: site.name, short_name: "Sonee Infratech", description: site.description, start_url: "/", display: "standalone",
    background_color: "#131922", theme_color: "#1E272C",
    icons: [{ src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" }],
  };
}
