import PageHeader from "@/components/PageHeader";
import TeamCard from "@/components/TeamCard";
import CTASection from "@/components/CTASection";
import { team } from "@/data/team";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "Our Team: Engineers, Architects & Project Managers",
  description: "Meet the engineers, architects and project managers who deliver our construction projects.",
  path: "/team",
});

export default function TeamPage() {
  return (
    <>
      <PageHeader title="Our team" text="The engineers, architects and site managers behind every project." image="/images/interior.svg" />
      <section className="mx-auto max-w-6xl px-5 py-16">
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {team.map((m, i) => (<li key={`${m.name}-${i}`}><TeamCard member={m} /></li>))}
        </ul>
      </section>
      <CTASection />
    </>
  );
}
