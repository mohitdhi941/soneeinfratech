import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({ title: "Terms & Conditions", description: "Terms & Conditions for our construction website.", path: "/terms" });

export default function Page() {
  return (
    <section className="mx-auto max-w-3xl px-5 pb-20 pt-36">
      <h1 className="text-4xl">Terms & Conditions</h1>
      <p className="mt-4 text-ink-500">Placeholder. Replace with your legal text before launch.</p>
    </section>
  );
}
