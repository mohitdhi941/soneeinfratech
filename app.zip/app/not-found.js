import Button from "@/components/Button";
export const metadata = { title: "Page not found", robots: { index: false } };
export default function NotFound() {
  return (
    <section className="mx-auto max-w-3xl px-5 pb-24 pt-40 text-center">
      <h1 className="text-5xl">Page not found</h1>
      <p className="mt-4 text-ink-500">The page you are looking for has moved or does not exist.</p>
      <Button href="/" className="mt-8">Back to home</Button>
    </section>
  );
}
