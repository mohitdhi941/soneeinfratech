// Soft fade-in on every page navigation.
export default function Template({ children }) {
  return <div className="page-in">{children}</div>;
}
