import Image from "next/image";
import PageHeader from "@/components/PageHeader";
import SectionHeading from "@/components/SectionHeading";
import StatsSection from "@/components/StatsSection";
import CTASection from "@/components/CTASection";
import Icon from "@/components/Icon";
import Reveal from "@/components/Reveal";
import { values, reasons } from "@/data/about";
import { journey } from "@/data/services";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "About Us",
  description: "Learn about our construction company, our vision, mission and values, and how we manage the complete lifecycle from foundation to final handover.",
  path: "/about",
});

export default function AboutPage() {
  return (
    <>
      <PageHeader title="Building with care, from foundation to handover" text="A construction company that manages the complete project lifecycle under one roof." />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <SectionHeading title="Who we are" />
          <p className="mt-4 leading-relaxed text-ink-500">Placeholder company introduction. Replace this with your company story: when it started, what it stands for and the kind of work it is known for. We build residential, commercial and township projects, and finish them with interiors, exteriors, landscaping and plantation.</p>
        </Reveal>
        <div className="relative aspect-[4/3] overflow-hidden rounded-3xl">
          <Image src="/images/residential.svg" alt="Completed residential building with landscaped frontage" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" />
        </div>
      </section>
      <StatsSection />
      <section className="mx-auto grid max-w-6xl gap-6 px-5 py-20 md:grid-cols-2">
        <article className="rounded-3xl bg-stone-100 p-8"><h2 className="text-3xl">Our vision</h2><p className="mt-3 text-ink-500">Placeholder vision statement. To be recognised as the most dependable builder in our region.</p></article>
        <article className="rounded-3xl bg-stone-100 p-8"><h2 className="text-3xl">Our mission</h2><p className="mt-3 text-ink-500">Placeholder mission statement. To deliver well-built spaces on time, with honest communication throughout.</p></article>
      </section>
      <section className="bg-ink py-20 text-white">
        <div className="mx-auto max-w-6xl px-5">
          <SectionHeading title="Our values" light />
          <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v) => (<li key={v.title} className="rounded-3xl border border-white/10 p-6"><h3 className="text-xl text-brass-400">{v.title}</h3><p className="mt-2 text-stone-300">{v.text}</p></li>))}
          </ul>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-20 lg:grid-cols-2">
        <div>
          <SectionHeading title="Why choose us" />
          <ul className="mt-6 grid gap-3">
            {reasons.map((r) => (<li key={r} className="flex items-start gap-3"><Icon name="check" className="mt-1 h-5 w-5 shrink-0 text-brass" />{r}</li>))}
          </ul>
        </div>
        <div>
          <h2 className="text-3xl sm:text-4xl">End-to-end capability</h2>
          <p className="mt-4 text-ink-500">{journey.map((j) => j.title).join(", ")}. We manage every stage of the construction lifecycle.</p>
        </div>
      </section>
      <CTASection />
    </>
  );
}
