import PageHeader from "@/components/PageHeader";
import ProjectsGrid from "@/components/ProjectsGrid";
import CTASection from "@/components/CTASection";
import { getProjects, projectCategories } from "@/data/projects";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "Our Projects: Residential, Commercial & Township",
  description: "Browse our portfolio of residential, commercial and township construction projects.",
  path: "/projects",
});

export default async function ProjectsPage() {
  const projects = await getProjects();
  return (
    <>
      <PageHeader title="Our projects" text="Residential, commercial and township work, built from foundation to handover." image="/images/commercial.svg" />
      <section className="mx-auto max-w-6xl px-5 py-16">
        <ProjectsGrid projects={projects} categories={projectCategories} />
      </section>
      <CTASection />
    </>
  );
}
