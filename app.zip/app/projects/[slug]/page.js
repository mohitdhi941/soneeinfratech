import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import Button from "@/components/Button";
import CTASection from "@/components/CTASection";
import ProjectGallery from "@/components/ProjectGallery";
import Icon from "@/components/Icon";
import JsonLd from "@/components/JsonLd";
import { getProject, getProjectSlugs } from "@/data/projects";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/lib/site";

export function generateStaticParams() {
  return getProjectSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }) {
  const p = await getProject(params.slug);
  if (!p) return {};
  return buildMetadata({ title: `${p.title}: ${p.category} Project in ${p.location}`, description: p.summary, path: `/projects/${p.slug}`, image: p.image });
}

export default async function ProjectPage({ params }) {
  const p = await getProject(params.slug);
  if (!p) notFound();
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      { "@type": "BreadcrumbList", itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: site.url },
        { "@type": "ListItem", position: 2, name: "Projects", item: `${site.url}/projects` },
        { "@type": "ListItem", position: 3, name: p.title } ] },
      { "@type": "CreativeWork", name: p.title, description: p.summary, image: `${site.url}${p.image}`, locationCreated: p.location, creator: { "@type": "Organization", name: site.name } },
    ],
  };
  const facts = [["Type", p.category], ["Location", p.location], ["Area", p.details.area], ["Duration", p.details.duration], ["Year", p.details.year], ["Status", p.details.status]];
  return (
    <>
      <JsonLd data={schema} />
      <article>
        <header className="relative isolate overflow-hidden bg-ink pb-14 pt-32 sm:pt-40">
          <Image src={p.image} alt={`${p.title}, ${p.category.toLowerCase()} project`} fill priority sizes="100vw" className="-z-10 object-cover opacity-50" />
          <div className="mx-auto max-w-6xl px-5">
            <Link href="/projects" className="inline-flex min-h-11 items-center text-sm text-stone-300 hover:text-white">&larr; All projects</Link>
            <h1 className="mt-2 max-w-3xl text-4xl text-white sm:text-6xl">{p.title}</h1>
            <p className="mt-3 max-w-xl text-lg text-stone-200">{p.summary}</p>
          </div>
        </header>
        <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="text-3xl">About this project</h2>
            <p className="mt-4 leading-relaxed text-ink-500">{p.description}</p>
            <h2 className="mt-10 text-3xl">Gallery</h2>
            <div className="mt-4"><ProjectGallery images={p.gallery} title={p.title} /></div>
            <h2 className="mt-10 text-3xl">Highlights</h2>
            <ul className="mt-4 grid gap-3">{p.highlights.map((h) => (<li key={h} className="flex gap-3"><Icon name="check" className="mt-1 h-5 w-5 shrink-0 text-brass" />{h}</li>))}</ul>
          </div>
          <aside className="h-fit rounded-3xl border border-stone-200 bg-white p-6">
            <h2 className="text-2xl">Project facts</h2>
            <dl className="mt-4 divide-y divide-stone-200">
              {facts.map(([k, v]) => (<div key={k} className="flex justify-between gap-4 py-3"><dt className="text-ink-500">{k}</dt><dd className="text-right font-medium">{v}</dd></div>))}
            </dl>
            <Button href="/contact#enquiry" className="mt-4 w-full">Start a similar project</Button>
          </aside>
        </div>
      </article>
      <CTASection />
    </>
  );
}
