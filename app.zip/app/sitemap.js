import { site } from "@/lib/site";
import { services } from "@/data/services";
import { getProjectSlugs } from "@/data/projects";

export default function sitemap() {
  const pages = ["", "/about", "/what-we-do", "/projects", "/team", "/contact", "/privacy-policy", "/terms"];
  const now = new Date();
  return [
    ...pages.map((p) => ({ url: `${site.url}${p}`, lastModified: now, changeFrequency: "monthly", priority: p === "" ? 1 : 0.8 })),
    ...services.map((s) => ({ url: `${site.url}/services/${s.slug}`, lastModified: now, changeFrequency: "monthly", priority: 0.7 })),
    ...getProjectSlugs().map((s) => ({ url: `${site.url}/projects/${s}`, lastModified: now, changeFrequency: "monthly", priority: 0.6 })),
  ];
}
