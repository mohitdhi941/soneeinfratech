import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Analytics from "@/components/Analytics";
import ScrollProgress from "@/components/ScrollProgress";
import WhatsAppButton from "@/components/WhatsAppButton";
import MobileActionBar from "@/components/MobileActionBar";
import JsonLd from "@/components/JsonLd";
import { site } from "@/lib/site";

const display = Playfair_Display({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const sans = Inter({ subsets: ["latin"], variable: "--font-sans", display: "swap" });

export const metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} | Construction & Pest Control Company`, template: `%s | ${site.name}` },
  description: site.description,
  keywords: ["construction company", "residential construction", "commercial construction", "township development", "landscaping", "plantation", "turnkey construction", "pest control", "termite control"],
  alternates: { canonical: "/" },
  openGraph: { type: "website", siteName: site.name, url: "/", title: site.name, description: site.description, images: [{ url: "/images/og.jpg", width: 1200, height: 630, alt: site.name }] },
  twitter: { card: "summary_large_image", title: site.name, description: site.description, images: ["/images/og.jpg"] },
  robots: { index: true, follow: true },
  verification: process.env.NEXT_PUBLIC_GSC_VERIFICATION ? { google: process.env.NEXT_PUBLIC_GSC_VERIFICATION } : undefined,
  category: "construction",
};

export const viewport = { themeColor: "#1E272C", width: "device-width", initialScale: 1 };

const orgSchema = {
  "@context": "https://schema.org",
  "@type": "GeneralContractor",
  name: site.name,
  url: site.url,
  logo: `${site.url}/images/logo-full.png`,
  image: `${site.url}/images/og.jpg`,
  description: site.description,
  email: site.email,
  telephone: site.phone,
  address: { "@type": "PostalAddress", streetAddress: site.address },
  areaServed: site.serviceAreas,
  openingHours: ["Mo-Sa 09:00-18:00"],
  makesOffer: ["Residential Construction", "Commercial Construction", "Township Development", "Landscaping", "Plantation", "Pest Control"].map((n) => ({ "@type": "Offer", itemOffered: { "@type": "Service", name: n } })),
};

const websiteSchema = { "@context": "https://schema.org", "@type": "WebSite", name: site.name, url: site.url };

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body>
        <a href="#main" className="sr-only z-[60] rounded bg-white px-4 py-2 focus:not-sr-only focus:fixed focus:left-4 focus:top-4">Skip to content</a>
        <JsonLd data={orgSchema} />
        <JsonLd data={websiteSchema} />
        <Analytics />
        <ScrollProgress />
        <Navbar />
        <main id="main">{children}</main>
        <Footer />
        <WhatsAppButton />
        <MobileActionBar />
      </body>
    </html>
  );
}
