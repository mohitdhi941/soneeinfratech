import random, math
W,H=1600,1000
def wrap(body,defs=""):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" preserveAspectRatio="xMidYMid slice"><defs>{defs}<filter id="n"><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="2" seed="3"/><feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .07 0"/></filter></defs>{body}<rect width="{W}" height="{H}" filter="url(#n)"/></svg>'
def sky(c1,c2,c3,sun=(1150,520,380)):
    d=f'<linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset=".6" stop-color="{c2}"/><stop offset="1" stop-color="{c3}"/></linearGradient><radialGradient id="sun"><stop offset="0" stop-color="#F6D08A" stop-opacity=".95"/><stop offset=".4" stop-color="#E8A55A" stop-opacity=".35"/><stop offset="1" stop-color="#E8A55A" stop-opacity="0"/></radialGradient>'
    b=f'<rect width="{W}" height="{H}" fill="url(#s)"/><circle cx="{sun[0]}" cy="{sun[1]}" r="{sun[2]}" fill="url(#sun)"/>'
    return b,d
def tree(x,y,s,c="#2F4A33"):
    return f'<rect x="{x-3*s}" y="{y-40*s}" width="{6*s}" height="{40*s}" fill="#1c1a18"/><ellipse cx="{x}" cy="{y-70*s}" rx="{34*s}" ry="{48*s}" fill="{c}"/><ellipse cx="{x-14*s}" cy="{y-58*s}" rx="{22*s}" ry="{30*s}" fill="#3C5C40" opacity=".7"/>'
def windows(x,y,w,h,r,lit="#F2C677",step=(30,40),p=.4,dark="#1b2a36"):
    o=""
    for wy in range(int(y+14),int(y+h-30),step[1]):
        for wx in range(int(x+12),int(x+w-24),step[0]):
            c=lit if r.random()<p else dark
            o+=f'<rect x="{wx}" y="{wy}" width="{step[0]-12}" height="{step[1]-16}" fill="{c}" opacity="{.95 if c==lit else .7}"/>'
    return o
def hero():
    r=random.Random(1); b,d=sky("#1f2530","#6b5a58","#d9955a")
    o=b
    for i in range(14):  # far skyline
        w=r.randint(60,130);h=r.randint(180,400);x=i*120+r.randint(-20,20)
        o+=f'<rect x="{x}" y="{H-120-h}" width="{w}" height="{h}" fill="#3b3a44" opacity=".55"/>'
    x=-20
    while x<W:  # near towers
        w=r.randint(130,230);h=r.randint(300,700);y=H-120-h
        o+=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#15161b"/><rect x="{x}" y="{y}" width="6" height="{h}" fill="#d9955a" opacity=".5"/>'+windows(x,y,w,h,r,p=.32)
        x+=w+r.randint(8,30)
    # crane
    o+='<g stroke="#0d0d10" stroke-width="7" fill="none"><path d="M420 880V260M420 260H900M420 260L330 300M780 260V400M420 330L780 260"/></g><rect x="770" y="400" width="24" height="26" fill="#0d0d10"/><rect x="408" y="236" width="28" height="30" fill="#B7822E"/>'
    o+=f'<rect y="{H-120}" width="{W}" height="120" fill="#0d0d10"/>'
    return wrap(o,d)
def villa():
    r=random.Random(2); b,d=sky("#2a3342","#8c7a70","#e6b27a",(1250,480,330)); o=b
    o+='<rect y="640" width="1600" height="360" fill="#23301f"/>'
    o+='<rect x="260" y="440" width="820" height="190" fill="#e9e2d6"/><rect x="180" y="400" width="620" height="44" fill="#2a2724"/><rect x="520" y="250" width="640" height="190" fill="#cfc4b3"/><rect x="470" y="212" width="740" height="40" fill="#2a2724"/>'
    o+='<rect x="300" y="470" width="320" height="150" fill="#1e2a35"/><rect x="300" y="470" width="320" height="150" fill="#F2C677" opacity=".55"/><rect x="660" y="470" width="360" height="150" fill="#1e2a35"/><rect x="700" y="285" width="400" height="120" fill="#1e2a35"/><rect x="700" y="285" width="400" height="120" fill="#F2C677" opacity=".4"/>'
    o+='<rect x="240" y="628" width="860" height="14" fill="#8a7a66"/><path d="M0 760C400 700 900 720 1600 800V1000H0Z" fill="#2c3b27"/><rect x="900" y="780" width="500" height="120" rx="10" fill="#4f93a8" opacity=".85"/>'
    for x,y,s in [(120,690,2.2),(1180,660,2.6),(1500,700,2.4),(1320,860,3)]: o+=tree(x,y,s)
    return wrap(o,d)
def tower():
    r=random.Random(3); d='<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9fb3c4"/><stop offset=".5" stop-color="#4a5f72"/><stop offset="1" stop-color="#1b2631"/></linearGradient>'
    o=f'<rect width="{W}" height="{H}" fill="url(#g)"/>'
    for i in range(0,W,80):
        o+=f'<rect x="{i}" width="3" height="{H}" fill="#0d141b" opacity=".55"/>'
    for j in range(0,H,70): o+=f'<rect y="{j}" width="{W}" height="3" fill="#0d141b" opacity=".55"/>'
    for _ in range(70):
        x=r.randrange(0,W,80);y=r.randrange(0,H,70); o+=f'<rect x="{x+3}" y="{y+3}" width="77" height="67" fill="#F2C677" opacity="{r.uniform(.15,.5):.2f}"/>'
    o+='<path d="M0 0H700L0 900Z" fill="#fff" opacity=".07"/>'
    return wrap(o,d)
def township():
    r=random.Random(4); b,d=sky("#34425a","#a58f82","#e9bd8a",(300,420,360)); o=b
    o+='<path d="M0 520C300 470 600 520 900 480S1400 470 1600 500V1000H0Z" fill="#3a4a35"/><path d="M0 640C400 600 1000 700 1600 600V1000H0Z" fill="#2e3c2b"/>'
    o+='<path d="M-50 1000C500 800 900 760 1700 640L1700 700C1000 800 600 860 100 1000Z" fill="#3d3a38"/><path d="M-50 1000C500 800 900 760 1700 640" stroke="#E8D9B5" stroke-width="4" stroke-dasharray="28 22" fill="none" opacity=".7"/>'
    for row,(y0,sc) in enumerate([(600,.8),(520,.6),(700,1.1)]):
        x=40+row*50
        while x<W-100:
            w=int(110*sc);h=int(70*sc);col=r.choice(["#eadfce","#c9b99f","#f3ece0"])
            o+=f'<rect x="{x}" y="{y0-h}" width="{w}" height="{h}" fill="{col}"/><path d="M{x-8} {y0-h}L{x+w/2} {y0-h-int(46*sc)}L{x+w+8} {y0-h}Z" fill="#8b4a34"/><rect x="{x+w*.4}" y="{y0-h*.55}" width="{w*.2}" height="{h*.55}" fill="#3b2a22"/>'
            x+=w+int(70*sc)+r.randint(0,40)
            if r.random()<.5:o+=tree(x-30,y0,1.1*sc+.3)
    return wrap(o,d)
def interior():
    d='<linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a6f50"/><stop offset="1" stop-color="#5a4630"/></linearGradient><linearGradient id="w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#bcd0de"/><stop offset="1" stop-color="#f1d9b0"/></linearGradient>'
    o='<rect width="1600" height="1000" fill="#e7dfd2"/><rect x="180" y="120" width="760" height="560" fill="url(#w)"/><rect x="180" y="120" width="760" height="560" fill="none" stroke="#2a2724" stroke-width="14"/><path d="M560 120V680M180 400H940" stroke="#2a2724" stroke-width="8"/><path d="M0 700H1600V1000H0Z" fill="url(#f)"/>'
    o+='<rect x="1060" y="180" width="320" height="220" fill="#B7822E" opacity=".85"/><rect x="1090" y="210" width="260" height="160" fill="#2a2724" opacity=".85"/>'
    o+='<rect x="260" y="560" width="620" height="170" rx="26" fill="#6b645c"/><rect x="240" y="500" width="120" height="230" rx="30" fill="#5a544d"/><rect x="780" y="500" width="120" height="230" rx="30" fill="#5a544d"/><rect x="300" y="520" width="200" height="80" rx="20" fill="#B7822E" opacity=".8"/>'
    o+='<rect x="1180" y="440" width="10" height="280" fill="#2a2724"/><path d="M1130 440L1240 440L1220 360H1150Z" fill="#F2C677"/><circle cx="1185" cy="440" r="160" fill="#F2C677" opacity=".12"/><ellipse cx="560" cy="860" rx="420" ry="70" fill="#d8cdbb" opacity=".8"/>'
    return wrap(o,d)
def construction():
    r=random.Random(5); b,d=sky("#2b3340","#8d7b6e","#e1a76a",(1300,560,320)); o=b
    for c in range(5):
        x=200+c*260
        o+=f'<rect x="{x}" y="300" width="26" height="600" fill="#6d6a66"/>'
    for f in range(5):
        y=300+f*120; o+=f'<rect x="170" y="{y}" width="1100" height="22" fill="#8c8982"/>'
    o+='<g stroke="#d6dde2" stroke-width="3" opacity=".6">'+"".join(f'<path d="M{200+i*130} 300V900M{200+i*130} 300L{200+i*130+130} 420"/>' for i in range(8))+'</g>'
    o+='<g stroke="#0d0d10" stroke-width="8" fill="none"><path d="M1380 920V120M1380 120H800M1380 120L1450 160M900 120V300"/></g><rect x="1366" y="96" width="30" height="34" fill="#B7822E"/><rect x="0" y="900" width="1600" height="100" fill="#2a2420"/>'
    return wrap(o,d)
def garden(lush="#2F4A33"):
    r=random.Random(6); b,d=sky("#8fb0c0","#dbd0b4","#f0d9a8",(500,380,300)); o=b
    o+='<path d="M0 520C400 450 900 470 1600 440V1000H0Z" fill="#6a8a52"/><path d="M0 640C500 580 1000 620 1600 560V1000H0Z" fill="#4e7040"/>'
    o+='<path d="M640 1000C700 820 760 700 820 600L900 600C860 720 900 860 1100 1000Z" fill="#d9ceb8"/>'
    o+='<g fill="#2a2724"><rect x="1100" y="420" width="16" height="230"/><rect x="1380" y="420" width="16" height="230"/><rect x="1080" y="410" width="340" height="18"/></g><g stroke="#2a2724" stroke-width="6">'+"".join(f'<path d="M{1090+i*40} 428V470"/>' for i in range(9))+'</g>'
    for x,y,s in [(180,640,3.2),(430,600,2.6),(1500,700,3.4),(1000,640,2.2),(300,760,2)]: o+=tree(x,y,s,lush)
    for i in range(24):
        x=r.randint(80,1520);y=r.randint(720,950);o+=f'<ellipse cx="{x}" cy="{y}" rx="{r.randint(30,60)}" ry="{r.randint(16,30)}" fill="{r.choice(["#3c5c40","#5b7f45","#B7822E","#c46a4a"])}" opacity=".85"/>'
    return wrap(o,d)
def plantation():
    r=random.Random(7); b,d=sky("#4b6a73","#a9b48c","#ecd49a",(1100,420,340)); o=b
    for i,(y,c) in enumerate([(430,"#587a5a"),(520,"#46684a"),(620,"#385a3e")]):
        o+=f'<path d="M0 {y}C400 {y-90} 900 {y+40} 1600 {y-60}V1000H0Z" fill="{c}"/>'
    for row,(y,s) in enumerate([(640,1.2),(740,1.8),(880,2.6)]):
        for x in range(40+row*60,1600,int(200/ (1+row*.2))): o+=tree(x+r.randint(-15,15),y,s,r.choice(["#2F4A33","#35603a","#2a4a30"]))
    return wrap(o,d)
for n,f in dict(hero=hero,residential=villa,commercial=tower,township=township,interior=interior,construction=construction,landscaping=garden,plantation=plantation).items():
    open(f"public/images/{n}.svg","w").write(f())
