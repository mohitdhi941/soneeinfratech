/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: "#1E272C", 800: "#2A353B", 700: "#38444B", 500: "#5F6B72" },
        stone: { 50: "#FAF8F5", 100: "#F3EFE9", 200: "#E6DFD5", 300: "#D4CABC" },
        brass: { DEFAULT: "#C48A3F", 600: "#9E6B26", 400: "#E0B168", 100: "#F7EBD6" },
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      keyframes: {
        kenburns: { "0%": { transform: "scale(1)" }, "100%": { transform: "scale(1.09)" } },
        marquee: { to: { transform: "translateX(-50%)" } },
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
      },
      animation: {
        kenburns: "kenburns 24s ease-in-out infinite alternate",
        marquee: "marquee 38s linear infinite",
        float: "float 6s ease-in-out infinite",
      },
      boxShadow: { lift: "0 18px 40px -18px rgba(35,33,31,.35)" },
    },
  },
  plugins: [],
};
