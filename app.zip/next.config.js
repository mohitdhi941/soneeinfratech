/** @type {import('next').NextConfig} */
const nextConfig = {
  // Placeholder images are SVG. Replace with real JPG/WebP photos in /public/images
  // and you can remove these two options.
  images: { dangerouslyAllowSVG: true, contentDispositionType: "attachment", contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;" },
  poweredByHeader: false,
  async headers() {
    return [{ source: "/(.*)", headers: [
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "X-Frame-Options", value: "SAMEORIGIN" },
    ] }];
  },
};
module.exports = nextConfig;
