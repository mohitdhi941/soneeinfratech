export const faqs = [
  { q: "Do you handle a project from start to finish?", a: "Yes. We manage the full lifecycle: planning, site preparation, foundation, structure, electrical and plumbing, interiors, exteriors, landscaping, quality inspection and final handover." },
  { q: "What types of projects do you build?", a: "Residential (villas, independent houses, luxury homes, apartments), commercial (offices, retail, institutional buildings) and township development." },
  { q: "Do you also do landscaping and plantation?", a: "Yes. Garden design, landscaping, plantation and green-area development are part of our services, and can be delivered together with the building." },
  { q: "How do I get a quote?", a: "Send us an enquiry with your project type and a few details, or call us. Our team will get back to you to discuss scope and next steps." },
  { q: "Can I hire you for only one part of the work?", a: "Yes. You can choose a single service such as finishing or landscaping, or let us manage the entire project." },
  { q: "Do you provide pest control services?", a: "Yes. We offer termite control (before and after construction), bed bug treatment, cockroach control and general pest control for residential, commercial and township sites." },
];
