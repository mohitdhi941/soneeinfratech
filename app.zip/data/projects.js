// Placeholder data. Replace with real projects, or swap getProjects() for an API call later.
const projects = [
  { slug: "sample-villa-residence", title: "Sample Villa Residence", category: "Residential", location: "City, State", image: "/images/residential.svg",
    summary: "A contemporary independent villa with landscaped courtyard.",
    description: "Placeholder description. Replace with the real project story: the brief, the challenges and how the team delivered from foundation to handover.",
    details: { area: "0,000 sq ft", duration: "00 months", year: "20XX", status: "Completed" },
    highlights: ["Full turnkey delivery", "Custom interior finishing", "Landscaped garden"] },
  { slug: "sample-luxury-apartments", title: "Sample Luxury Apartments", category: "Residential", location: "City, State", image: "/images/interior.svg",
    summary: "A low-rise apartment block with premium interior finishing.",
    description: "Placeholder description. Replace with real project information.",
    details: { area: "00,000 sq ft", duration: "00 months", year: "20XX", status: "Completed" },
    highlights: ["RCC frame construction", "Premium flooring", "Common-area landscaping"] },
  { slug: "sample-corporate-office", title: "Sample Corporate Office", category: "Commercial", location: "City, State", image: "/images/commercial.svg",
    summary: "A multi-storey office building with efficient floor plates.",
    description: "Placeholder description. Replace with real project information.",
    details: { area: "00,000 sq ft", duration: "00 months", year: "20XX", status: "Completed" },
    highlights: ["Structural construction", "Electrical & plumbing", "Exterior facade"] },
  { slug: "sample-retail-complex", title: "Sample Retail Complex", category: "Commercial", location: "City, State", image: "/images/construction.svg",
    summary: "A retail and showroom complex built to a tight schedule.",
    description: "Placeholder description. Replace with real project information.",
    details: { area: "00,000 sq ft", duration: "00 months", year: "20XX", status: "Ongoing" },
    highlights: ["Fast-track schedule", "Waterproofing", "Final finishing"] },
  { slug: "sample-green-township", title: "Sample Green Township", category: "Township", location: "City, State", image: "/images/township.svg",
    summary: "A planned residential township with roads, parks and common areas.",
    description: "Placeholder description. Replace with real project information.",
    details: { area: "00 acres", duration: "00 months", year: "20XX", status: "Ongoing" },
    highlights: ["Roads & infrastructure", "Community spaces", "Large-scale plantation"] },
  { slug: "sample-gated-community", title: "Sample Gated Community", category: "Township", location: "City, State", image: "/images/plantation.svg",
    summary: "A gated community with villas, clubhouse and green belts.",
    description: "Placeholder description. Replace with real project information.",
    details: { area: "00 acres", duration: "00 months", year: "20XX", status: "Completed" },
    highlights: ["Villa clusters", "Green belts", "Landscaped entrances"] },
];

const extra = ["/images/interior.svg", "/images/landscaping.svg", "/images/construction.svg", "/images/residential.svg"];
projects.forEach((p) => { p.gallery = [p.image, ...extra.filter((x) => x !== p.image).slice(0, 3)]; });

export const projectCategories = ["All", "Residential", "Commercial", "Township"];
export async function getProjects() { return projects; }
export async function getProject(slug) { return projects.find((p) => p.slug === slug) ?? null; }
export function getProjectSlugs() { return projects.map((p) => p.slug); }
export default projects;
