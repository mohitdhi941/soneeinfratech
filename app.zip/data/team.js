export const team = [
  { name: "Team Member One", role: "Founder & Managing Director", image: "/images/team-1.svg", bio: "Placeholder bio. Leads the company vision and key client relationships." },
  { name: "Team Member Two", role: "Chief Engineer", image: "/images/team-2.svg", bio: "Placeholder bio. Oversees structural design, site engineering and quality." },
  { name: "Team Member Three", role: "Head of Projects", image: "/images/team-3.svg", bio: "Placeholder bio. Manages schedules, subcontractors and site delivery." },
  { name: "Team Member Four", role: "Architect", image: "/images/team-4.svg", bio: "Placeholder bio. Turns client briefs into buildable, well-resolved designs." },
  { name: "Team Member Five", role: "Interior & Finishing Lead", image: "/images/team-1.svg", bio: "Placeholder bio. Responsible for interiors, finishes and final detailing." },
  { name: "Team Member Six", role: "Landscape Specialist", image: "/images/team-2.svg", bio: "Placeholder bio. Designs gardens, plantation and green-area development." },
];
