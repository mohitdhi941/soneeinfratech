export const stats = [
  { value: "XX+", label: "Projects Completed" },
  { value: "XX+", label: "Years of Experience" },
  { value: "XX+", label: "Happy Clients" },
  { value: "XX+", label: "Construction Experts" },
];
export const values = [
  { title: "Integrity", text: "Honest estimates, clear communication and no surprises." },
  { title: "Quality", text: "Material checks and site inspections at every stage." },
  { title: "Reliability", text: "Realistic schedules, and a team that keeps to them." },
  { title: "Safety", text: "Safe sites for our people, neighbours and clients." },
];
export const reasons = [
  "One team from foundation to handover",
  "Transparent planning, budgets and progress updates",
  "In-house engineering, finishing and landscaping",
  "Quality inspection before every handover",
];
