export const services = [
  { slug: "end-to-end-construction", icon: "layers", image: "/images/construction.svg", title: "End-to-End Construction",
    description: "One accountable team from site planning to handover, so you deal with a single point of contact.",
    points: ["Site planning", "Foundation work", "RCC & structural construction", "Brick / block work", "Plumbing & electrical", "Waterproofing", "Project handover"] },
  { slug: "residential-construction", icon: "home", image: "/images/residential.svg", title: "Residential Construction",
    description: "Homes built around how you live, with careful detailing and dependable schedules.",
    points: ["Villas", "Independent houses", "Luxury homes", "Apartments"] },
  { slug: "commercial-construction", icon: "building", image: "/images/commercial.svg", title: "Commercial Construction",
    description: "Functional, durable buildings for businesses and institutions.",
    points: ["Offices", "Commercial buildings", "Retail spaces", "Institutional buildings"] },
  { slug: "township-development", icon: "city", image: "/images/township.svg", title: "Township Development",
    description: "Planned communities delivered at scale, including the infrastructure that connects them.",
    points: ["Large residential developments", "Community development", "Infrastructure", "Roads & common areas", "Landscaping"] },
  { slug: "interior-exterior-finishing", icon: "paint", image: "/images/interior.svg", title: "Interior & Exterior Finishing",
    description: "Flooring, painting and finishes that give a building its final character.",
    points: ["Flooring", "Painting", "Interior finishing", "Exterior finishing", "Final finishing"] },
  { slug: "landscaping-gardening", icon: "leaf", image: "/images/landscaping.svg", title: "Landscaping & Gardening",
    description: "Outdoor spaces designed and built alongside the building, then maintained after.",
    points: ["Garden design", "Landscaping", "Outdoor spaces", "Garden maintenance"] },
  { slug: "plantation-green-development", icon: "tree", image: "/images/plantation.svg", title: "Plantation & Green Development",
    description: "Tree plantation and green-area development that matures with your project.",
    points: ["Plantation", "Green-area development", "Common-area greenery"] },
];

export const pestControl = {
  slug: "pest-control-services", icon: "shield", image: "/images/pest-control.svg", title: "Pest Control Services",
  description: "Termite, bed bug and cockroach control for homes, offices and townships, from construction stage to ongoing protection.",
  points: ["Termite control (pre- and post-construction)", "Bed bug treatment", "Cockroach control", "General pest control", "Residential, commercial and township sites", "Scheduled follow-up visits"],
};
services.push(pestControl);

const extra = {
  "end-to-end-construction": ["From site planning to handover, one team manages every stage of your building so there are fewer delays and no gaps between contractors.", ["end to end construction", "turnkey construction company", "building contractor"]],
  "residential-construction": ["We build villas, independent houses, luxury homes and apartments with careful detailing and dependable schedules.", ["residential construction", "villa construction", "house builders", "apartment construction"]],
  "commercial-construction": ["Offices, retail spaces and institutional buildings, built to be functional, durable and ready for business.", ["commercial construction", "office building contractor", "retail space construction"]],
  "township-development": ["Large residential developments with roads, infrastructure, community spaces and landscaping delivered as one coordinated project.", ["township development", "residential township builder", "infrastructure development"]],
  "interior-exterior-finishing": ["Flooring, painting, interior and exterior finishing, and the final detailing that gives a building its character.", ["interior finishing", "exterior finishing", "flooring and painting contractor"]],
  "landscaping-gardening": ["Garden design, landscaping and outdoor spaces planned alongside the building, with maintenance after handover.", ["landscaping services", "garden design", "garden maintenance"]],
  "plantation-green-development": ["Tree plantation and green-area development for homes, campuses and townships.", ["plantation services", "green area development", "tree plantation"]],
  "pest-control-services": ["Protecting a building starts before it is built. We offer termite control at the construction stage and after it, effective bed bug treatment, cockroach control and general pest control for homes, offices and townships. Scheduled follow-up visits keep the protection working.", ["pest control services", "termite control", "anti termite treatment", "bed bug treatment", "cockroach control", "residential pest control", "commercial pest control"]],
};
services.forEach((s) => { const [long, keywords] = extra[s.slug]; s.long = long; s.keywords = keywords; });
export const getService = (slug) => services.find((s) => s.slug === slug) ?? null;

export const journey = [
  { title: "Planning", text: "Scope, budget, drawings and approvals." },
  { title: "Site Preparation", text: "Clearing, levelling and marking out." },
  { title: "Foundation", text: "Excavation, footing, plinth and anti-termite treatment." },
  { title: "Structure", text: "RCC frame, slabs, brick and block work." },
  { title: "Electrical & Plumbing", text: "Concealed services and waterproofing." },
  { title: "Interior Work", text: "Flooring, joinery, painting and fittings." },
  { title: "Exterior Work", text: "Facade, plaster and exterior finishes." },
  { title: "Landscaping", text: "Gardens, plantation and outdoor areas." },
  { title: "Quality Inspection", text: "Checks against drawings and standards." },
  { title: "Final Handover", text: "Snag closure, documents and keys." },
];
