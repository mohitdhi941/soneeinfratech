// SAMPLE content. Replace with real client feedback before launch.
export const testimonials = [
  { name: "Client Name", role: "Villa owner, City", text: "Sample testimonial. Replace with genuine feedback about communication, quality and handover experience." },
  { name: "Client Name", role: "Business owner, City", text: "Sample testimonial. Mention the project type, the timeline and what stood out about working with the team." },
  { name: "Client Name", role: "Developer, City", text: "Sample testimonial. A short, specific quote works best, ideally with the client's real name and photo." },
];
