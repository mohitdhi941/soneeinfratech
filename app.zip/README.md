# Construction Company Website (Next.js + Tailwind, JavaScript)

Static, SEO-first marketing site. App Router, no TypeScript, no backend.

## Run
```bash
npm install
cp .env.example .env.local   # set NEXT_PUBLIC_SITE_URL (https://www.soneeinfratech.com)
npm run dev                  # http://localhost:3000
npm run build && npm start
```

## Replace placeholders
- Company details, nav: `lib/site.js`
- Projects / services / team / stats: `data/*.js`
- Images: drop real JPG/WebP into `public/images` and update paths in `data/*.js`
  (placeholders are SVG; then remove the `dangerouslyAllowSVG` options in `next.config.js`)
- Privacy and Terms text: `app/privacy-policy`, `app/terms`
- Maps: replace the placeholder in `app/contact/page.js`

## Connect a backend later
- Enquiries: `lib/api.js` (`submitEnquiry` has the fetch to `POST /api/enquiry` ready, commented)
- Projects: `data/projects.js` exports async `getProjects()` / `getProject(slug)`; swap in API calls

## SEO extras
- Service pages: `/services/[slug]` (from `data/services.js`), with Service + Breadcrumb schema
- `public/llms.txt` (AI search), `app/manifest.js`, sitemap, robots
- Analytics: set `NEXT_PUBLIC_GA_ID`; Search Console: set `NEXT_PUBLIC_GSC_VERIFICATION`
- Replace `site.city` / `serviceAreas` in `lib/site.js` with real areas for local SEO
