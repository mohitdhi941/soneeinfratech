import Image from "next/image";
import Icon from "@/components/Icon";
import SectionHeading from "@/components/SectionHeading";

const small = [
  { icon: "check", title: "Quality checked", text: "Inspection at every stage, not just at the end." },
  { icon: "clock", title: "Clear schedules", text: "Realistic timelines and regular progress updates." },
  { icon: "leaf", title: "Greenery built in", text: "Landscaping and plantation planned with the building." },
];

export default function BentoWhy() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <SectionHeading eyebrow="WHY CHOOSE US" title="One accountable team, start to handover" text="Fewer hand-offs means fewer delays, clearer costs and a better finish." />
      <div className="mt-12 grid gap-4 lg:grid-cols-3 lg:grid-rows-2">
        <article className="group relative isolate flex min-h-[320px] flex-col justify-end overflow-hidden rounded-3xl bg-ink p-8 text-white lg:col-span-2 lg:row-span-2">
          <Image src="/images/construction.svg" alt="" fill sizes="(min-width:1024px) 66vw, 100vw" className="-z-10 object-cover opacity-60 transition duration-700 group-hover:scale-105" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink via-ink/50 to-transparent" />
          <h3 className="max-w-md text-3xl sm:text-4xl">From the first foundation to the final handover</h3>
          <p className="mt-3 max-w-md text-stone-300">Structure, services, interiors, exteriors and landscaping, all managed in-house.</p>
        </article>
        {small.map((s) => (
          <article key={s.title} className="rounded-3xl border border-stone-200 bg-white p-7 transition hover:-translate-y-1 hover:shadow-lift">
            <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-brass-100 text-brass-600"><Icon name={s.icon} /></span>
            <h3 className="mt-4 text-xl">{s.title}</h3>
            <p className="mt-2 text-ink-500">{s.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
