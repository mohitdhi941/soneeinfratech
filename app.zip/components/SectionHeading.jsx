export default function SectionHeading({ title, text, align = "left", as: Tag = "h2", light = false, eyebrow }) {
  const center = align === "center";
  return (
    <div className={`max-w-2xl ${center ? "mx-auto text-center" : ""}`}>
      {eyebrow && <p className={`mb-4 flex items-center gap-3 text-sm font-medium tracking-[0.18em] ${center ? "justify-center" : ""} ${light ? "text-brass-400" : "text-brass-600"}`}><span aria-hidden="true" className="h-px w-8 bg-current" />{eyebrow}</p>}
      <Tag className={`text-3xl leading-tight sm:text-4xl lg:text-5xl ${light ? "text-white" : "text-ink"}`}>{title}</Tag>
      {text && <p className={`mt-4 text-base leading-relaxed sm:text-lg ${light ? "text-stone-300" : "text-ink-500"}`}>{text}</p>}
    </div>
  );
}
