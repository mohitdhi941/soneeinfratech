import Image from "next/image";
import Link from "next/link";
import Icon from "@/components/Icon";

export default function ProjectCard({ project }) {
  return (
    <article className="group overflow-hidden rounded-3xl border border-stone-200 bg-white transition hover:shadow-lift">
      <Link href={`/projects/${project.slug}`} className="block" aria-label={`View project: ${project.title}`}>
        <div className="relative aspect-[4/3] overflow-hidden">
          <Image src={project.image} alt={`${project.title}, ${project.category.toLowerCase()} project in ${project.location}`} fill sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" className="object-cover transition duration-700 group-hover:scale-105" />
          <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-xs font-medium text-ink">{project.category}</span>
        </div>
        <div className="p-6">
          <h3 className="text-2xl">{project.title}</h3>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-500"><Icon name="pin" className="h-4 w-4" />{project.location}</p>
          <p className="mt-3 text-ink-500">{project.summary}</p>
          <span className="mt-5 inline-flex min-h-11 items-center gap-2 font-medium text-brass-600">View Project <Icon name="arrow" className="h-4 w-4 transition group-hover:translate-x-1" /></span>
        </div>
      </Link>
    </article>
  );
}
