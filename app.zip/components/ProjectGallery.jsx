"use client";
import Image from "next/image";
import { useRef, useState } from "react";

export default function ProjectGallery({ images, title }) {
  const ref = useRef(null);
  const [i, setI] = useState(0);
  const open = (n) => { setI(n); ref.current?.showModal(); };
  const step = (d) => setI((x) => (x + d + images.length) % images.length);
  return (
    <>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {images.map((src, n) => (
          <li key={src}>
            <button type="button" onClick={() => open(n)} aria-label={`Open image ${n + 1} of ${images.length}`} className="group relative block aspect-[4/3] w-full overflow-hidden rounded-2xl">
              <Image src={src} alt={`${title}, view ${n + 1}`} fill sizes="(min-width:640px) 25vw, 50vw" className="object-cover transition duration-700 group-hover:scale-110" />
            </button>
          </li>
        ))}
      </ul>
      <dialog ref={ref} aria-label={`${title} gallery`} onClick={(e) => e.target === ref.current && ref.current.close()}
        className="w-[92vw] max-w-5xl bg-transparent p-0 backdrop:bg-black/85 backdrop:backdrop-blur-sm">
        <div className="relative aspect-[16/10] overflow-hidden rounded-3xl bg-ink">
          <Image src={images[i]} alt={`${title}, view ${i + 1}`} fill sizes="92vw" className="object-cover" />
          <button type="button" onClick={() => step(-1)} aria-label="Previous image" className="absolute left-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-xl">&lsaquo;</button>
          <button type="button" onClick={() => step(1)} aria-label="Next image" className="absolute right-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-xl">&rsaquo;</button>
          <button type="button" onClick={() => ref.current.close()} aria-label="Close gallery" className="absolute right-3 top-3 flex h-11 w-11 items-center justify-center rounded-full bg-white/90 text-lg">&times;</button>
        </div>
      </dialog>
    </>
  );
}
