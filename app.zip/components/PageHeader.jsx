import Image from "next/image";
import Link from "next/link";
import JsonLd from "@/components/JsonLd";
import { site } from "@/lib/site";

// Page-level hero for inner pages. Renders the single H1.
export default function PageHeader({ title, text, image = "/images/construction.svg", alt = "", crumbs }) {
  return (
    <header className="relative isolate overflow-hidden bg-ink pt-28 pb-14 sm:pt-36 sm:pb-20">
      <Image src={image} alt={alt} fill priority sizes="100vw" className="-z-10 object-cover opacity-40" />
      <div className="mx-auto max-w-6xl px-5">
        {crumbs && (
          <>
            <JsonLd data={{ "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ name: "Home", href: "/" }, ...crumbs].map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: `${site.url}${c.href}` })) }} />
            <nav aria-label="Breadcrumb" className="mb-4 text-sm text-stone-300"><ol className="flex flex-wrap gap-2"><li><Link href="/" className="hover:text-white">Home</Link></li>{crumbs.map((c, i) => (<li key={c.href} className="flex gap-2"><span aria-hidden="true">/</span>{i === crumbs.length - 1 ? <span aria-current="page" className="text-white">{c.name}</span> : <Link href={c.href} className="hover:text-white">{c.name}</Link>}</li>))}</ol></nav>
          </>
        )}
        <h1 className="hero-in max-w-3xl text-4xl text-white sm:text-5xl lg:text-6xl">{title}</h1>
        {text && <p className="hero-in-2 mt-4 max-w-2xl text-base text-stone-300 sm:text-lg">{text}</p>}
      </div>
    </header>
  );
}
