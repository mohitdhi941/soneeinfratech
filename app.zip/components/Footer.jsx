import Link from "next/link";
import Image from "next/image";
import Button from "@/components/Button";
import Icon from "@/components/Icon";
import { navLinks, site } from "@/lib/site";
import { services } from "@/data/services";
import projects from "@/data/projects";

const col = "text-sm text-stone-300 transition hover:text-white inline-block py-1";

export default function Footer() {
  return (
    <footer className="bg-ink pb-28 text-white lg:pb-10">
      <div className="border-b border-white/10 px-5 py-14 text-center">
        <p className="font-display text-3xl sm:text-4xl">Have a project in mind?</p>
        <p className="mt-2 text-lg text-stone-300">Let&apos;s build it together.</p>
        <Button href="/contact#enquiry" className="mt-6">Enquire Now</Button>
      </div>
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <Link href="/" className="inline-block" aria-label={`${site.name} home`}>
            <Image src="/images/logo-full.png" alt={`${site.name}: ${site.tagline}`} width={1000} height={650} className="h-auto w-64" />
          </Link>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-stone-300">{site.description}</p>
          <ul className="mt-5 flex flex-wrap gap-2">
            {site.social.map((s) => (<li key={s.label}><a href={s.href} className="inline-flex min-h-10 items-center rounded-full border border-white/20 px-4 text-sm text-stone-200 hover:border-brass hover:text-white">{s.label}</a></li>))}
          </ul>
        </div>
        <nav aria-label="Quick links"><h2 className="font-display text-lg">Quick Links</h2><ul className="mt-3">{navLinks.map((l) => <li key={l.href}><Link href={l.href} className={col}>{l.label}</Link></li>)}</ul></nav>
        <nav aria-label="Services"><h2 className="font-display text-lg">Services</h2><ul className="mt-3">{services.map((s) => <li key={s.slug}><Link href={`/services/${s.slug}`} className={col}>{s.title}</Link></li>)}</ul></nav>
        <div>
          <h2 className="font-display text-lg">Projects</h2>
          <ul className="mt-3">{projects.slice(0, 3).map((p) => <li key={p.slug}><Link href={`/projects/${p.slug}`} className={col}>{p.title}</Link></li>)}</ul>
          <h2 className="mt-6 font-display text-lg">Contact</h2>
          <ul className="mt-3 grid gap-2 text-sm text-stone-300">
            <li className="flex gap-2"><Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0" />{site.address}</li>
            <li className="flex gap-2"><Icon name="phone" className="mt-0.5 h-4 w-4 shrink-0" />{site.phone}</li>
            <li className="flex gap-2"><Icon name="mail" className="mt-0.5 h-4 w-4 shrink-0" />{site.email}</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto flex max-w-6xl flex-col gap-3 border-t border-white/10 px-5 pt-6 text-sm text-stone-400 sm:flex-row sm:justify-between">
        <p>&copy; {new Date().getFullYear()} {site.name}. All rights reserved.</p>
        <p className="flex gap-5"><Link href="/privacy-policy" className="hover:text-white">Privacy Policy</Link><Link href="/terms" className="hover:text-white">Terms &amp; Conditions</Link></p>
      </div>
    </footer>
  );
}
