import Button from "@/components/Button";

export default function CTASection({ title = "Have a project in mind?", text = "Let's build it together.", cta = "Enquire Now" }) {
  return (
    <section className="px-5 py-16">
      <div className="mx-auto max-w-6xl rounded-[2rem] bg-ink px-6 py-14 text-center text-white sm:px-12">
        <h2 className="text-3xl sm:text-5xl">{title}</h2>
        <p className="mx-auto mt-3 max-w-xl text-lg text-stone-300">{text}</p>
        <Button href="/contact#enquiry" className="mt-8" arrow>{cta}</Button>
      </div>
    </section>
  );
}
