import SectionHeading from "@/components/SectionHeading";
import { testimonials } from "@/data/testimonials";

export default function Testimonials() {
  return (
    <section className="bg-stone-100 py-20">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading eyebrow="CLIENT WORDS" title="What our clients say" />
        <ul className="-mx-5 mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0">
          {testimonials.map((t, i) => (
            <li key={i} className="min-w-[85%] snap-center md:min-w-0">
              <figure className="flex h-full flex-col rounded-3xl border border-stone-200 bg-white p-7">
                <span aria-hidden="true" className="font-display text-6xl leading-none text-brass">&ldquo;</span>
                <blockquote className="mt-2 flex-1 text-ink-700">{t.text}</blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink font-medium text-brass-400">{t.name[0]}</span>
                  <span><span className="block font-medium">{t.name}</span><span className="text-sm text-ink-500">{t.role}</span></span>
                </figcaption>
              </figure>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
