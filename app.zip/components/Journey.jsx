import { journey } from "@/data/services";

export default function Journey() {
  return (
    <ol className="relative mt-12 grid gap-0 sm:grid-cols-2">
      {journey.map((s, i) => (
        <li key={s.title} className="relative flex gap-4 pb-8 sm:pr-8">
          <span className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brass font-medium text-white">{i + 1}</span>
          {i < journey.length - 1 && <span aria-hidden="true" className="absolute left-5 top-10 h-full w-px bg-stone-300 sm:hidden" />}
          <div><h3 className="text-xl">{s.title}</h3><p className="mt-1 text-ink-500">{s.text}</p></div>
        </li>
      ))}
    </ol>
  );
}
