"use client";
import { useEffect, useRef, useState } from "react";

// Lightweight scroll reveal. Use sparingly, around whole sections only.
export default function Reveal({ children, className = "", as: Tag = "div" }) {
  const ref = useRef(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) return setOn(true);
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <Tag ref={ref} className={`reveal ${on ? "is-visible" : ""} ${className}`}>{children}</Tag>;
}
