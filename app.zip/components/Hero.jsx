import Image from "next/image";
import Button from "@/components/Button";

const cards = [
  { k: "XX+", v: "Projects delivered" },
  { k: "1 team", v: "Foundation to handover" },
  { k: "3 types", v: "Residential · Commercial · Township" },
];

export default function Hero() {
  return (
    <section className="relative isolate flex min-h-[100svh] items-end overflow-hidden bg-ink pb-20 pt-32 sm:items-center sm:pb-28">
      <Image src="/images/hero.svg" alt="Modern building under construction at dusk" fill priority sizes="100vw" className="-z-30 animate-kenburns object-cover" />
      <div className="absolute inset-0 -z-20 bg-gradient-to-t from-ink via-ink/65 to-ink/20 sm:bg-gradient-to-r sm:from-ink sm:via-ink/65 sm:to-transparent" />
      <div aria-hidden="true" className="grid-lines absolute inset-0 -z-10 opacity-40 [mask-image:linear-gradient(to_right,black,transparent_70%)]" />
      <div className="mx-auto grid w-full max-w-6xl items-end gap-12 px-5 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="hero-in mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm text-stone-100 backdrop-blur">
            <span aria-hidden="true" className="h-2 w-2 rounded-full bg-brass" />Residential · Commercial · Township
          </p>
          <h1 className="hero-in-2 max-w-3xl text-5xl leading-[1.04] text-white sm:text-6xl lg:text-7xl">Built Strong. <span className="text-brass-400">Designed to Last.</span></h1>
          <p className="hero-in-3 mt-6 max-w-xl text-lg text-stone-200">Building spaces. Creating lasting value. We take your project from the first foundation to the day you move in, with interiors, exteriors, landscaping and pest protection, all under one roof.</p>
          <div className="hero-in-3 mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href="/contact#enquiry" arrow>Start Your Project</Button>
            <Button href="/projects" variant="outline" className="text-white">View Our Projects</Button>
          </div>
        </div>
        <ul className="hidden gap-3 lg:grid">
          {cards.map((c, i) => (
            <li key={c.k} style={{ animationDelay: `${i * 0.8}s` }} className="animate-float rounded-2xl border border-white/15 bg-white/10 p-5 text-white backdrop-blur-md">
              <p className="font-display text-3xl text-brass-400">{c.k}</p><p className="text-sm text-stone-200">{c.v}</p>
            </li>
          ))}
        </ul>
      </div>
      <a href="#intro" aria-label="Scroll to content" className="absolute bottom-6 left-1/2 hidden h-12 w-7 -translate-x-1/2 justify-center rounded-full border border-white/40 pt-2 sm:flex"><span className="h-2 w-1 animate-float rounded bg-white" /></a>
    </section>
  );
}
