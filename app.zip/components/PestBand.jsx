import Image from "next/image";
import Button from "@/components/Button";
import SectionHeading from "@/components/SectionHeading";
import Icon from "@/components/Icon";
import { pestControl } from "@/data/services";

export default function PestBand() {
  return (
    <section className="relative isolate overflow-hidden bg-ink py-20 text-white">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 lg:grid-cols-2">
        <div>
          <SectionHeading light eyebrow="PROTECT WHAT YOU BUILD" title="Pest control, built into your project" text="Termites, bed bugs, cockroaches and more: we protect your building from the foundation stage to long after you move in." />
          <ul className="mt-6 grid gap-3 text-stone-200 sm:grid-cols-2">
            {pestControl.points.slice(0, 4).map((p) => (<li key={p} className="flex items-start gap-2"><Icon name="check" className="mt-0.5 h-5 w-5 shrink-0 text-brass-400" />{p}</li>))}
          </ul>
          <Button href={`/services/${pestControl.slug}`} className="mt-8" arrow>Explore pest control</Button>
        </div>
        <div className="relative aspect-[4/3] overflow-hidden rounded-3xl border border-white/10 shadow-lift">
          <Image src={pestControl.image} alt="Shield protecting a home from pests" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" />
        </div>
      </div>
    </section>
  );
}
