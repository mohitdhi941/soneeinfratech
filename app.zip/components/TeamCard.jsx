import Image from "next/image";

export default function TeamCard({ member }) {
  return (
    <article className="overflow-hidden rounded-3xl border border-stone-200 bg-white">
      <div className="relative aspect-[5/6] bg-stone-200">
        <Image src={member.image} alt={`Portrait of ${member.name}`} fill sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" className="object-cover" />
      </div>
      <div className="p-6">
        <h3 className="text-xl">{member.name}</h3>
        <p className="mt-1 text-sm font-medium text-brass-600">{member.role}</p>
        <p className="mt-3 text-ink-500">{member.bio}</p>
      </div>
    </article>
  );
}
