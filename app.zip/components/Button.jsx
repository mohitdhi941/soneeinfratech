import Link from "next/link";
import Icon from "@/components/Icon";

const variants = {
  primary: "relative overflow-hidden bg-brass text-white hover:bg-brass-600 shadow-lift before:absolute before:inset-0 before:-translate-x-full before:bg-gradient-to-r before:from-transparent before:via-white/30 before:to-transparent before:transition-transform before:duration-700 hover:before:translate-x-full",
  dark: "bg-ink text-white hover:bg-ink-700",
  outline: "border border-current hover:bg-white/10",
  ghost: "text-ink hover:bg-stone-100",
};

export default function Button({ href, variant = "primary", arrow = false, className = "", children, ...props }) {
  const cls = `inline-flex min-h-12 items-center whitespace-nowrap justify-center gap-2 rounded-full px-6 text-[15px] font-medium transition active:scale-[.98] ${variants[variant]} ${className}`;
  const content = (<>{children}{arrow && <Icon name="arrow" className="h-4 w-4" />}</>);
  if (href) return <Link href={href} className={cls} {...props}>{content}</Link>;
  return <button className={cls} {...props}>{content}</button>;
}
