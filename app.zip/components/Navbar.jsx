"use client";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Icon from "@/components/Icon";
import Button from "@/components/Button";
import { navLinks, site } from "@/lib/site";

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => { window.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open]);

  const isActive = (href) => (href === "/" ? pathname === "/" : pathname.startsWith(href));
  const solid = scrolled || open;

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${solid ? "bg-ink/95 py-3 shadow-lg backdrop-blur" : "py-5"}`}>
      <nav aria-label="Main" className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5">
        <Link href="/" className="flex shrink-0 items-center gap-2.5" aria-label={`${site.name} home`}>
          <Image src="/images/logo-mark.png" alt="" width={460} height={336} priority className="h-9 w-auto lg:h-10" />
          <Image src="/images/logo-wordmark.png" alt={site.name} width={900} height={65} priority className="hidden h-[13px] w-auto min-[340px]:block lg:h-[14px]" />
        </Link>

        <ul className="hidden items-center lg:flex xl:gap-1">
          {navLinks.map((l) => (
            <li key={l.href}>
              <Link href={l.href} aria-current={isActive(l.href) ? "page" : undefined}
                className={`relative whitespace-nowrap rounded-full px-2.5 py-2 text-[13px] transition xl:px-3.5 xl:text-sm ${isActive(l.href) ? "text-white" : "text-stone-300 hover:text-white"}`}>
                {l.label}
                <span className={`absolute inset-x-3 -bottom-0.5 h-0.5 origin-left rounded bg-brass transition-transform ${isActive(l.href) ? "scale-x-100" : "scale-x-0"}`} />
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <Button href="/contact#enquiry" className="hidden min-h-10 px-5 text-sm lg:inline-flex">Get a Quote</Button>
          <button type="button" className="flex h-11 w-11 items-center justify-center rounded-full text-white lg:hidden"
            aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen((o) => !o)}>
            <Icon name={open ? "close" : "menu"} />
          </button>
        </div>
      </nav>

      <div id="mobile-menu" hidden={!open} className="lg:hidden">
        <div className="mx-auto max-w-6xl px-5 pb-6 pt-4">
          <ul className="grid gap-1">
            {navLinks.map((l) => (
              <li key={l.href}>
                <Link href={l.href} aria-current={isActive(l.href) ? "page" : undefined}
                  className={`flex min-h-14 items-center justify-between rounded-2xl px-4 text-lg ${isActive(l.href) ? "bg-white/10 text-white" : "text-stone-300"}`}>
                  {l.label}{isActive(l.href) && <span className="h-2 w-2 rounded-full bg-brass" />}
                </Link>
              </li>
            ))}
          </ul>
          <Button href="/contact#enquiry" className="mt-4 w-full">Get a Quote</Button>
        </div>
      </div>
    </header>
  );
}
