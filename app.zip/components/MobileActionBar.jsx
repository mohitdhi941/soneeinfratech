import Link from "next/link";
import Icon from "@/components/Icon";
import { site } from "@/lib/site";

// App-style sticky action bar, mobile only.
export default function MobileActionBar() {
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 flex gap-2 rounded-full bg-ink/95 p-2 shadow-lift backdrop-blur lg:hidden" style={{ paddingBottom: "calc(0.5rem + env(safe-area-inset-bottom))" }}>
      <a href={`tel:${site.phone.replace(/\s/g, "")}`} className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full text-sm font-medium text-white" aria-label="Call us">
        <Icon name="phone" className="h-5 w-5" /> Call
      </a>
      <Link href="/contact#enquiry" className="flex min-h-12 flex-[2] items-center justify-center rounded-full bg-brass text-sm font-medium text-white">Enquire Now</Link>
    </div>
  );
}
