const paths = {
  layers: "M12 3 3 8l9 5 9-5-9-5Zm-9 9 9 5 9-5M3 16l9 5 9-5",
  home: "M3 11 12 4l9 7v9H3v-9Zm6 9v-6h6v6",
  building: "M5 21V4h9v17M14 9h5v12M8 8h3M8 12h3M8 16h3M3 21h18",
  city: "M3 21V10l5-3v14M8 21V4l7 3v14M15 21v-9l6 2v7M2 21h20",
  paint: "M5 4h12v5H5V4Zm6 5v4m-2 0h4v8h-4v-8Z",
  leaf: "M5 19c0-8 5-14 15-14 0 10-6 15-14 15M5 19l7-7",
  tree: "M12 22v-6m0 0c-4 0-6-2.5-6-5.5 0-2 1.2-3.2 2.5-3.8C8.2 5 10 3 12 3s3.8 2 3.5 3.7c1.3.6 2.5 1.8 2.5 3.8 0 3-2 5.5-6 5.5Z",
  shield: "M12 3 4 6v6c0 4.5 3.2 8 8 9 4.800-1 8-4.500 8-9V6l-8-3Zm-3 9 2.500 2.500L15.500 10",
  check: "m5 12 5 5 9-10",
  phone: "M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z",
  mail: "M3 6h18v12H3V6Zm0 0 9 7 9-7",
  pin: "M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Zm0-8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-14v5l3 2",
  arrow: "M5 12h14m-6-6 6 6-6 6",
  menu: "M4 7h16M4 12h16M4 17h16",
  close: "M6 6l12 12M18 6 6 18",
};
export default function Icon({ name, className = "h-6 w-6" }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true" focusable="false">
      <path d={paths[name]} />
    </svg>
  );
}
