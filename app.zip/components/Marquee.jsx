const items = ["Foundation", "RCC Structure", "Plumbing & Electrical", "Waterproofing", "Interiors", "Exteriors", "Landscaping", "Plantation", "Pest Control", "Final Handover"];

export default function Marquee() {
  const row = items.map((t) => (
    <span key={t} className="flex items-center gap-8 whitespace-nowrap font-display text-2xl text-white/90 sm:text-3xl">
      {t}<span aria-hidden="true" className="h-2 w-2 rounded-full bg-brass" />
    </span>
  ));
  return (
    <section aria-label="Our capabilities" className="overflow-hidden border-y border-white/10 bg-ink py-6">
      <div className="flex w-max animate-marquee gap-8 hover:[animation-play-state:paused]">
        <div className="flex gap-8">{row}</div>
        <div className="flex gap-8" aria-hidden="true">{row}</div>
      </div>
    </section>
  );
}
