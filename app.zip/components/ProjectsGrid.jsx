"use client";
import { useState } from "react";
import ProjectCard from "@/components/ProjectCard";

export default function ProjectsGrid({ projects, categories }) {
  const [active, setActive] = useState("All");
  const shown = active === "All" ? projects : projects.filter((p) => p.category === active);
  return (
    <div>
      <div role="group" aria-label="Filter projects by type" className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-2 sm:mx-0 sm:flex-wrap sm:px-0">
        {categories.map((c) => (
          <button key={c} type="button" aria-pressed={active === c} onClick={() => setActive(c)}
            className={`min-h-11 shrink-0 rounded-full border px-5 text-sm font-medium transition ${active === c ? "border-ink bg-ink text-white" : "border-stone-300 bg-white text-ink hover:border-ink"}`}>{c}</button>
        ))}
      </div>
      <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3" aria-live="polite">
        {shown.map((p) => (<li key={p.slug}><ProjectCard project={p} /></li>))}
      </ul>
    </div>
  );
}
