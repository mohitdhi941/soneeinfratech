import SectionHeading from "@/components/SectionHeading";
import JsonLd from "@/components/JsonLd";
import { faqs } from "@/data/faq";

export default function Faq() {
  const schema = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) };
  return (
    <section className="mx-auto max-w-3xl px-5 py-20">
      <JsonLd data={schema} />
      <SectionHeading eyebrow="FAQ" title="Questions, answered" align="center" />
      <div className="mt-10 grid gap-3">
        {faqs.map((f) => (
          <details key={f.q} className="group rounded-2xl border border-stone-200 bg-white px-6 open:shadow-sm">
            <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 py-4 font-medium [&::-webkit-details-marker]:hidden">
              {f.q}
              <span aria-hidden="true" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brass-100 text-brass-600 transition group-open:rotate-45">+</span>
            </summary>
            <p className="pb-5 text-ink-500">{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
