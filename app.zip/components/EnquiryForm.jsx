"use client";
import { useState } from "react";
import Button from "@/components/Button";
import Icon from "@/components/Icon";
import { submitEnquiry } from "@/lib/api";

const types = ["Residential", "Commercial", "Township Development", "Pest Control", "Other"];
const empty = { name: "", email: "", phone: "", projectType: "", description: "" };

function validate(v) {
  const e = {};
  if (!v.name.trim()) e.name = "Please enter your name.";
  if (!v.email.trim()) e.email = "Please enter your email address.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) e.email = "Enter a valid email, like name@example.com.";
  const digits = v.phone.replace(/\D/g, "");
  if (!v.phone.trim()) e.phone = "Please enter your phone number.";
  else if (!/^[+\d\s()-]+$/.test(v.phone) || digits.length < 7 || digits.length > 15) e.phone = "Enter a valid phone number (7 to 15 digits).";
  return e;
}

const field = "mt-2 min-h-12 w-full rounded-2xl border bg-white px-4 text-base outline-none transition focus:border-brass focus:ring-2 focus:ring-brass/30";

export default function EnquiryForm() {
  const [values, setValues] = useState(empty);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | loading | success | error

  const set = (k) => (e) => {
    setValues((v) => ({ ...v, [k]: e.target.value }));
    if (errors[k]) setErrors((x) => ({ ...x, [k]: undefined }));
  };

  async function onSubmit(e) {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) { document.getElementById(`f-${Object.keys(found)[0]}`)?.focus(); return; }
    setStatus("loading");
    try { await submitEnquiry(values); setStatus("success"); setValues(empty); }
    catch { setStatus("error"); }
  }

  if (status === "success") {
    return (
      <div role="status" className="rounded-3xl border border-stone-200 bg-white p-8 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brass-100 text-brass-600"><Icon name="check" className="h-7 w-7" /></span>
        <h3 className="mt-4 text-2xl">Enquiry sent</h3>
        <p className="mt-2 text-ink-500">Thank you. Our team will contact you shortly to discuss your project.</p>
        <Button variant="dark" className="mt-6" onClick={() => setStatus("idle")}>Send another enquiry</Button>
      </div>
    );
  }

  const Err = ({ id, msg }) => msg ? <p id={id} className="mt-1.5 text-sm text-red-700">{msg}</p> : null;
  const bd = (k) => (errors[k] ? "border-red-600" : "border-stone-300");

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 rounded-3xl border border-stone-200 bg-white p-6 shadow-sm sm:p-8">
      <fieldset className="grid gap-5">
        <legend className="mb-1 font-display text-xl">Your details</legend>
        <div>
          <label htmlFor="f-name" className="text-sm font-medium">Name <span aria-hidden="true" className="text-red-700">*</span></label>
          <input id="f-name" name="name" autoComplete="name" required aria-required="true" aria-invalid={!!errors.name} aria-describedby={errors.name ? "e-name" : undefined} value={values.name} onChange={set("name")} className={`${field} ${bd("name")}`} />
          <Err id="e-name" msg={errors.name} />
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="f-email" className="text-sm font-medium">Email <span aria-hidden="true" className="text-red-700">*</span></label>
            <input id="f-email" name="email" type="email" inputMode="email" autoComplete="email" required aria-required="true" aria-invalid={!!errors.email} aria-describedby={errors.email ? "e-email" : undefined} value={values.email} onChange={set("email")} className={`${field} ${bd("email")}`} />
            <Err id="e-email" msg={errors.email} />
          </div>
          <div>
            <label htmlFor="f-phone" className="text-sm font-medium">Phone number <span aria-hidden="true" className="text-red-700">*</span></label>
            <input id="f-phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" required aria-required="true" aria-invalid={!!errors.phone} aria-describedby={errors.phone ? "e-phone" : undefined} value={values.phone} onChange={set("phone")} className={`${field} ${bd("phone")}`} />
            <Err id="e-phone" msg={errors.phone} />
          </div>
        </div>
      </fieldset>
      <fieldset className="grid gap-5">
        <legend className="mb-1 font-display text-xl">Your project</legend>
        <div>
          <label htmlFor="f-projectType" className="text-sm font-medium">Project type</label>
          <select id="f-projectType" name="projectType" value={values.projectType} onChange={set("projectType")} className={`${field} border-stone-300`}>
            <option value="">Select a project type</option>
            {types.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="f-description" className="text-sm font-medium">Tell us about your project</label>
          <textarea id="f-description" name="description" rows={5} value={values.description} onChange={set("description")} className={`${field} min-h-32 border-stone-300 py-3`} />
        </div>
      </fieldset>
      {status === "error" && <p role="alert" className="text-sm text-red-700">We could not send your enquiry. Please try again or call us.</p>}
      <Button type="submit" disabled={status === "loading"} className="w-full disabled:opacity-60 sm:w-auto sm:self-start">
        {status === "loading" ? "Sending…" : "Send Enquiry"}
      </Button>
    </form>
  );
}
