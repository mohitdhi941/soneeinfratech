import { stats } from "@/data/about";

export default function StatsSection() {
  return (
    <section aria-label="Company statistics" className="bg-ink py-14 text-white">
      <dl className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-5 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label}>
            <dd className="order-1 font-display text-4xl text-brass-400 sm:text-5xl">{s.value}</dd>
            <dt className="mt-1 text-sm text-stone-300">{s.label}</dt>
          </div>
        ))}
      </dl>
    </section>
  );
}
