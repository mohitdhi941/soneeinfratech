import Image from "next/image";
import Link from "next/link";
import Icon from "@/components/Icon";

export default function ServiceCard({ service, detailed = false }) {
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-stone-200 bg-white transition hover:-translate-y-1 hover:shadow-lift">
      <div className="relative aspect-[16/10] overflow-hidden">
        <Image src={service.image} alt={`${service.title} service illustration`} fill sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" className="object-cover transition duration-700 group-hover:scale-105" />
      </div>
      <div className="flex flex-1 flex-col p-6">
        <span className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-brass-100 text-brass-600"><Icon name={service.icon} /></span>
        <h3 className="text-2xl"><Link href={`/services/${service.slug}`} className="after:absolute after:inset-0">{service.title}</Link></h3>
        <p className="mt-2 text-ink-500">{service.description}</p>
        {detailed && (
          <ul className="mt-4 grid gap-2 text-sm text-ink-700">
            {service.points.map((p) => (<li key={p} className="flex items-start gap-2"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-brass" />{p}</li>))}
          </ul>
        )}
      </div>
    </article>
  );
}
